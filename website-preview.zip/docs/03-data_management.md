---
title: Clinical Data Management
---



# Clinical Data Management

## Learning Objectives

## Clinical data handling tools

## Importance of keeping clinical data safe

## Government regulators

## Documentation

## Conclusion
