---
title: Clinical Data Uses
---



# Clinical Data Uses

## Learning Objectives

## General uses of clinical data

## Types of questions that can be asked with clinical data

## Research Design Considerations

## Conclusion
