# Specific Clinical Data Types

## Learning Objectives

<img src="01b-specific_data_types_files/figure-html//1ivDTcLjb2078O0GemkSeCgC1jmxk4fMsiFQaPaer9mQ_g3385bea4ad0_0_30.png" alt="Learning Objectives: 1. Explain why clinical data is unique compared to other types of biomedical research data, 2. Describe the difference between Structured and Unstructured data, 3. List major sources and types of clinical data" width="100%" style="display: block; margin: auto;" />



## Physiological

## Monitoring data

:::bluebox
This section was written by: Jennifer Kelleher, Ph.D.^1^; Abigail S. Robbertz, Ph.D.^1^; and Meghan E. McGrady, Ph.D.^1,2^

**NOTE:** Jennifer Kelleher, Ph.D.^1^ and Abigail S. Robbertz, Ph.D.^1^ contributed equally.

^1^ Center for Adherence and Self-Management, Division of Behavioral Medicine and Clinical Psychology, Cincinnati Children’s Hospital Medical Center, Cincinnati, OH, USA

^2^ Department of Pediatrics, University of Cincinnati College of Medicine, Cincinnati, OH, USA

The work discussed in this section was also supported by the National Cancer Institute at the National Institutes of Health (R21CA263704, K07CA200668) to MEM. JK and ASR are supported by the Eunice Kennedy Shriver National Institute of Child Health & Human Development at the National Institutes of Health (T32HD068223). The content is solely the responsibility of the authors and does not necessarily represent the official views of the National Institutes of Health.

:::

Electronic monitoring devices are digital tools that can be used to track health behaviors over time such as:

* Sleep
* Physical activity
* Medication adherence
* Calorie intake

Electronic monitoring devices can also be used to assess physical health indicators including:
* Blood glucose levels
* Blood pressure 
* Heart rate and heart rate variability
* Oxygen saturation

Electronic monitoring devices enable researchers to track day-to-day health behaviors in the patient’s **"real-world" setting**. This allows researchers to explore patterns or changes in a patient’s health behavior and provides a richer understanding of **daily behavior over time**. 


### Benefits of Monitoring Data

1) Electronic monitoring devices often include data transmission abilities that enable healthcare providers or researchers to access these data in near **real-time** potentially informing intervention and/or medical decision-making.

1) Electronic monitoring devices also have the potential to produce **more accurate** estimates of health behaviors than alternative strategies (e.g., self-report) as they are not subject to recall bias and can detect efforts to inflate adherence due to social desirability.

### Considerations

:::warning
This section is not exhaustive. Research teams are strongly encouraged to consult with experts with experience and training in collecting and analyzing data from specific devices.

To ensure the outcome variables are aligned with the research question of interest and [ethical and age/developmental considerations](https://pmc.ncbi.nlm.nih.gov/articles/PMC10798216/) (@psihogios_ethical_2024; @modi_pediatric_2012) have been appropriately accounted for, readers are encouraged to consult with researchers in their field who have integrated these measurement strategies into their work. 
:::

#### Medication Adherence

There are three major components of medical adherence (the tracking of taking medication):

- Initiation: Starting a prescribed regimen
- Implementation: The amount of which a patient's medication-taking behavior corresponds with the treatment regimen or protocol
- Discontinuation: Stopping a perscribed regimen

For more information see:

- [A new taxonomy for describing and defining adherence to medications (Vrijens et al., 2012)](https://pmc.ncbi.nlm.nih.gov/articles/PMC3403197/)
- [Pediatric self-management: A framework for research, practice, and policy. (Modi et al., 2012)](https://pmc.ncbi.nlm.nih.gov/articles/PMC9923567/)

## Radiology

## Pathology

## Synthetic Data

## Summary
